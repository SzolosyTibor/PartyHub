<?php
    session_start();
    session_unset();
    session_destroy();
    header( "location: https://webspact.hu/admin-panel/admins/login-admins.php");
?>


