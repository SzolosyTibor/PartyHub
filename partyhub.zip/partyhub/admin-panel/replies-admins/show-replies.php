<?php
ob_start(); // Start output buffering
require "../layouts/header.php";
require "../../config/config.php";

if (!isset($_SESSION['adminname'])) {
  header("location: " . ADMINURL . "/admins/login-admins.php ");
}

$replies = $conn->query("SELECT * FROM replies ");
$replies->execute();
$allReplies = $replies->fetchALL(PDO::FETCH_OBJ);

?>

<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title mb-4 d-inline">Komment</h5>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Komment</th>
              <th scope="col">Felhasználó képe</th>
              <th scope="col">Felhasználó neve</th>
              <th scope="col">Irány az eseményhez</th>
              <th scope="col">Törlés</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($allReplies as $reply) : ?>
              <tr>
                <th scope="row"><?php echo $reply->id; ?></th>
                <td><?php echo $reply->reply; ?></td>
                <td><a href="../../img/<?php echo $reply->user_image; ?>"><?php echo $reply->user_image; ?></a></td>
                <td><?php echo $reply->user_name; ?></td>
                <td><a href="https://facecontactno1.000webhostapp.com/topics/topic.php?id=<?php echo $reply->topic_id; ?>" class="btn btn-success text-center ">Irány az eseményhez</a></td>
                <td><a href="delete-replies.php?id=<?php echo $reply->id; ?>" class="btn btn-danger  text-center ">Törlés</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require "../layouts/footer.php"; ?>