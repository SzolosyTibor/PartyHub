<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php
if (!isset($_SESSION['username'])) {
	header("location: " . APPURL . " ");
}

if (isset($_POST['submit'])) {
	if (empty($_POST['title']) or empty($_POST['category']) or empty($_POST['body'])) {
		echo "<script> alert('one or more inputs are empty');</script>";
	} else {
		$title = $_POST['title'];
		$category = $_POST['category'];
		$body = $_POST['body'];
		$user_name = $_SESSION['name'];
		$user_image = $_SESSION['user_image'];

		// Képfeltöltés feldolgozása
		$target_dir = "../uploads/"; // Képfájlok mentési mappája
		$target_file = $target_dir . basename($_FILES["event_image"]["name"]); // Feltöltött fájl elérési útvonala
		move_uploaded_file($_FILES["event_image"]["tmp_name"], $target_file); // Fájl áthelyezése a cél helyre

		$insert = $conn->prepare("INSERT INTO topics (title, category, body, user_name, user_image, image) VALUES(:title, :category, :body, :user_name, :user_image, :image)");
		$insert->execute([
			":title" => $title,
			":category" => $category,
			":body" => $body,
			":user_name" => $user_name,
			":user_image" => $user_image,
			":image" => $target_file, // Elérési útvonal mentése az adatbázisba
		]);
		header("location: " . APPURL . " ");
	}
}

//grapping categories
$categories_select = $conn->query("SELECT * FROM categories ");
$categories_select->execute();
$allCats = $categories_select->fetchAll(PDO::FETCH_OBJ);
?>

<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="main-col">
				<div class="block">
					<h1 class="pull-left">Create A Topic</h1>
					<h4 class="pull-right">A Simple Forum</h4>
					<div class="clearfix"></div>
					<hr>
					<form role="form" method="POST" action="create.php" enctype="multipart/form-data"> <!-- enctype hozzáadása -->
						<div class="form-group">
							<label>Topic Title</label>
							<input type="text" class="form-control" name="title" placeholder="Enter Post Title">
						</div>
						<div class="form-group">
							<label>Category</label>
							<select name="category" class="form-control">
								<?php foreach ($allCats as $cat) : ?>
									<option value="<?php echo $cat->name; ?>"><?php echo $cat->name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Topic Body</label>
							<textarea id="body" rows="10" cols="80" class="form-control" name="body"></textarea>
						</div>
						<div class="form-group">
            				<label for="event_image">Kép feltöltése:</label><br>
            				<input type="file" id="event_image" name="event_image"><br><br>
						</div>
						<button style="margin-top:15px;" type="submit" name="submit" class="color btn btn-default">Create</button>
					</form>
				</div>
			</div>
		</div>
<?php require "../includes/footer.php" ?>
