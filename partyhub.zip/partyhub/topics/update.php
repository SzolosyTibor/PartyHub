<?php
ob_start(); // Start output buffering
require "../includes/header.php";
require "../config/config.php";
if (!isset($_SESSION['name'])) {
    header("location: ../index.php"); // Redirect to login page
    exit(); // Stop further execution
}


//grapping the data
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$select = $conn->query("SELECT * FROM topics WHERE id='$id' ");
	$select->execute();
	$topic = $select->fetch(PDO::FETCH_OBJ);
	if ($topic->user_name !== $_SESSION['username']) {
		header("location: " . APPURL . " ");
	}
}

if (isset($_POST['submit'])) {
	if (empty($_POST['title']) or empty($_POST['category']) or empty($_POST['body'])) {
		echo "<script> alert('one or more inputs are empty');</script>";
	} else {
		$title = $_POST['title'];
		$category = $_POST['category'];
		$body = $_POST['body'];
		$user_name = $_SESSION['name'];
		$user_image = $_SESSION['user_image'];

		// Képfeltöltés feldolgozása
		$target_dir = "../uploads/"; // Képfájlok mentési mappája
		$target_file = $target_dir . basename($_FILES["event_image"]["name"]); // Feltöltött fájl elérési útvonala
		move_uploaded_file($_FILES["event_image"]["tmp_name"], $target_file); // Fájl áthelyezése a cél helyre

		$insert = $conn->prepare("UPDATE topics SET title=:title, category=:category, body=:body, user_name=:user_name, image=:image WHERE id=:id");
		$insert->execute([
			":title" => $title,
			":category" => $category,
			":body" => $body,
			":user_name" => $user_name,
			":image" => $target_file, // Elérési útvonal mentése az adatbázisba
			":id" => $id,
		]);
		header("location: " . APPURL . " ");
	}
}
//grapping categories
$categories_select = $conn->query("SELECT * FROM categories ");
$categories_select->execute();
$allCats = $categories_select->fetchAll(PDO::FETCH_OBJ);
?>

<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="main-col">
				<div class="block">
					<h1 class="pull-left">Esemény szerkesztése</h1>
					<div class="clearfix"></div>
					<hr>
					<form role="form" method="POST" action="update.php?id=<?php echo $id; ?>" enctype="multipart/form-data"> <!-- enctype hozzáadása -->
						<div class="form-group">
							<label>Esemény címe</label>
							<input type="text" value="<?php echo $topic->title; ?> " class="form-control" name="title" placeholder="Cím">
						</div>
						<div class="form-group">
							<label>Kategória</label>
							<select name="category" class="form-control">
								<?php foreach ($allCats as $cat) : ?>
									<option value="<?php echo $cat->name; ?>"><?php echo $cat->name; ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="form-group">
							<label>Esemény leírása</label>
							<textarea id="body" rows="10" cols="80" class="form-control" name="body"><?php echo $topic->body; ?></textarea>
							<script>
								CKEDITOR.replace('body');
							</script>
						</div>
                        <div class="form-group">
            				<label for="event_image">Kép feltöltése:</label><br>
            				<input type="file" id="event_image" name="event_image"><br><br>
						</div>
						<button type="submit" name="submit" class="color btn btn-default">Frissítés</button>
					</form>
				</div>
			</div>
		</div>
<?php require "../includes/footer.php" ?>