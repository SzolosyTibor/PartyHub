-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 172.17.0.1:3306
-- Létrehozás ideje: 2024. Máj 15. 20:01
-- Kiszolgáló verziója: 10.5.22-MariaDB-1:10.5.22+maria~ubu2004-log
-- PHP verzió: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `iqk9hvzg`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `admins`
--

CREATE TABLE `admins` (
  `id` int(5) NOT NULL,
  `email` varchar(200) NOT NULL,
  `adminname` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `admins`
--

INSERT INTO `admins` (`id`, `email`, `adminname`, `password`, `created_at`) VALUES
(1, 'admin@gmail.com', 'Admin', '$2y$10$NrKqHO0wpeCPG2poTn9OZe9rDhjJudXxXn012BMjpC4xW6Gc5I99G', '2023-08-20 00:38:49'),
(2, 'admin.first@gmail.com', 'Admin 1', '$2y$10$3K65YpPer25A/2mubAKOvuMPaabW5eszgd8fOYd8t1CvBD3yRWpxa', '2023-08-20 02:04:41'),
(3, 'admin2@gmail.com', 'Admin 2', '$2y$10$MC5E6UZTbNWHao3eC5xhcenvpcasAXwMyTdbSWDgYA/9TpWYosAzu', '2023-08-20 04:53:33');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `categories`
--

CREATE TABLE `categories` (
  `id` int(5) NOT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(1, 'Koncertek', '2023-08-19 04:48:33'),
(2, 'Hivatalos rendezvények', '2023-08-19 04:48:33'),
(3, 'Családi programok', '2023-08-19 04:48:33'),
(4, 'Sport események', '2023-08-19 04:48:33'),
(5, 'Egyéb', '2023-08-20 05:47:08');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `replies`
--

CREATE TABLE `replies` (
  `id` int(5) NOT NULL,
  `reply` text NOT NULL,
  `user_id` int(5) NOT NULL,
  `user_image` varchar(200) NOT NULL,
  `topic_id` int(5) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `replies`
--

INSERT INTO `replies` (`id`, `reply`, `user_id`, `user_image`, `topic_id`, `user_name`, `created_at`) VALUES
(32, '<p>A &quot;Hung&aacute;ria Koncert - Most vagy Soha&quot; egy lenyűg&ouml;ző zenei &eacute;lm&eacute;ny, amelynek sor&aacute;n a legend&aacute;s magyar zenekar &uacute;jra felid&eacute;zi a nosztalgikus hangulatot &eacute;s felejthetetlen dallamokat. A koncert sor&aacute;n az egy&uuml;ttes energi&aacute;ja &eacute;s szenved&eacute;lye &aacute;tj&aacute;rja a k&ouml;z&ouml;ns&eacute;get, &eacute;s visszarep&iacute;t mindenkit azokba az időkbe, amikor a Hung&aacute;ria a hazai zenei &eacute;let kiemelkedő alakja volt. A &quot;Most vagy Soha&quot; koncert &uacute;jra megmutatja, hogy a Hung&aacute;ria zen&eacute;je &ouml;r&ouml;k &eacute;rv&eacute;nyű &eacute;s m&eacute;lyen gy&ouml;kerezik a magyar kult&uacute;r&aacute;ban, &eacute;s eml&eacute;keztet minket arra, hogy a j&oacute; zene soha nem avul el.</p>', 2, 'gravatar.png', 32, 'customer18@gmail.com', '2024-05-15 11:37:02');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `topics`
--

CREATE TABLE `topics` (
  `id` int(5) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_image` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `topics`
--

INSERT INTO `topics` (`id`, `title`, `category`, `body`, `user_name`, `user_image`, `created_at`, `image`) VALUES
(32, 'HUNGÁRIA KONCERT - MOST VAGY SOHA', 'Koncertek', 'A legendás Hungária zenekar most vagy soha koncertje igazi nosztalgia élményt ígér minden rajongónak. Szóljon a régi slágerekkel és élvezze a fergeteges hangulatot a Puskás Arénában!\r\nDátum: 2024. június 19.\r\nHelyszín: Puskás Aréna, Budapest\r\nElőadó: A Hungária zenekar', 'tesztelek@gmail.com', 'gravatar.png', '2024-05-15 09:41:08', '../uploads/image.jpg'),
(33, 'Nemzeti Tudományos Expo 2024', 'Hivatalos rendezvények', 'Dátum: 2024. június 15-18.\r\nHelyszín: Budapesti Nemzetközi Kiállítási Központ (BNKK)\r\nAz államfő és a tudományos közösség vezetői részvételével.\r\nA BNKK területén több pavilonban bemutatjuk a legfrissebb kutatásokat és innovációkat.\r\nRobotika, mesterséges intelligencia, környezetvédelem, űrkutatás és egészségügyi fejlesztések.\r\nMi kell még :D', 'tesztelek@gmail.com', 'gravatar.png', '2024-05-15 09:48:46', '../uploads/kép_2024-05-15_114840069.png'),
(34, 'Gyereknap 2024: programok Budapesten és vidéken', 'Családi programok', 'Gyereknap Margitsziget 2024 - május 19. és május 25.\r\nGyereknapi program a Vasút történeti Parkban - május 25 - 26.\r\nVárosligeti Gyereknap 2024 - május 25 - 26.\r\n2024-es Gyereknap a Bókay-Kertben - május 31 - június 2.\r\nHozd a famíliát, jó lesz a pulyáknak.', 'tesztelek@gmail.com', 'gravatar.png', '2024-05-15 10:01:48', '../uploads/kép_2024-05-15_120050546.png');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `about` text NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `about`, `avatar`, `created_at`) VALUES
(1, 'tesztelek@gmail.com', 'tesztelek@gmail.com ', 'tesztelek@gmail.com', '$2y$10$NrKqHO0wpeCPG2poTn9OZe9rDhjJudXxXn012BMjpC4xW6Gc5I99G', 'Teszt Elek vagyok, aki mindig a következő kaland után vágyakozik. Szeretek világot látni, új emberekkel találkozni és más kultúrákat felfedezni. Imádom a természetet, a hegységeket és a tengerpartokat egyaránt. Gyakran barangolok távoli helyekre, ahol a természet csodálatos látványaival találkozom, és inspirációt merítek a fotózás és az írás számára. Ha épp nem utazom, valószínűleg egy kávézóban vagyok, könyvet olvasva vagy éppen a következő úticél tervezgetése közben. Szeretem megosztani élményeimet és tanulni másoktól. Ha szeretnél beszélgetni vagy tippeket kérni utazáshoz kapcsolódóan, ne habozz megkeresni!', 'gravatar.png', '2023-08-19 08:11:59'),
(2, 'customer18@gmail.com ', 'customer18@gmail.com ', 'customer18@gmail.com ', '$2y$10$NrKqHO0wpeCPG2poTn9OZe9rDhjJudXxXn012BMjpC4xW6Gc5I99G', 'Sziasztok, custome18 vagyok! Zene minden, ami engem meghatároz. Imádom a különböző műfajokat felfedezni, legyen az rock, jazz, vagy éppen klasszikus zene. Egy igazi koncertrajongó vagyok, és gyakran találkozhattok velem a legújabb zenés eseményeken, vagy éppen egy kis klubban, ahol feltöltődöm a helyi zenekarok hangulatától. Amikor épp nem hallgatok zenét, akkor otthon vagyok, gyakran a gitárommal vagy éppen a zongorámon játszom. Szeretem megosztani másokkal a kedvenc zenéimet és felfedezéseimet, és mindig nyitott vagyok újabb ajánlásokra. Ha te is imádod a zenét, vagy csak egy jó koncerttársat keresel, ne habozz üzenni!', 'gravatar.png', '2023-08-19 08:11:59');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT a táblához `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT a táblához `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
