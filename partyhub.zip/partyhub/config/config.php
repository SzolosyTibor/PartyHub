<?php
try {
    //host 
    define("HOST", "localhost");
    //dbname
    define('DBNAME', 'iqk9hvzg');
    //user
    define('USER', 'iqk9hvzg');
    //password
    define('PASS', 'Webspact1');
    $conn = new PDO("mysql:host=".HOST.";dbname=".DBNAME."",USER, PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // if ($conn == true){
    //     echo "db connection is a success";
    // } else {
    //     echo "error";
    // }
    
} catch( PDOException $Exception ) {
    echo $Exception->getMessage(); 
}

?>