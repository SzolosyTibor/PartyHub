<?php
ob_start(); // Start output buffering
require "../includes/header.php";
require "../config/config.php";

// Check if the user is already logged in
if (isset($_SESSION['username'])) {
  header("location: " . APPURL);
  exit;
}

// Handle form submission
if (isset($_POST['submit'])) {
  if (empty($_POST['email']) || empty($_POST['password'])) {
    echo "<script>alert('One or more inputs are empty');</script>";
  } else {
    // Get the data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute the query
    $login = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $login->execute([$email]);
    $fetch = $login->fetch(PDO::FETCH_ASSOC);

    if ($login->rowCount() > 0 && password_verify($password, $fetch['password'])) {
      // Store user data in session and redirect
      $_SESSION['username'] = $fetch['username'];
      $_SESSION['name'] = $fetch['name'];
      $_SESSION['user_id'] = $fetch['id'];
      $_SESSION['email'] = $fetch['email'];
      $_SESSION['user_image'] = $fetch['avatar'];
      header("location: " . APPURL);
      exit;
    } else {
      echo "<script>alert('Email vagy a jelszó hibás!');</script>";
    }
  }
}
?>
<style>
    @media screen and (min-width: 500px) {
  .row {
      margin-right:25%; 
      margin-left:25%;
      margin-top:10%;
  }
  .col-md-8{
      width:100%;
  }
  
}
</style>
<div class="container">
  <div class="container">
	<div class="row">
		<div class="col-md-8" >
      <div class="main-col">
        <div class="block">
          <h1 class="pull-left">Bejelentkezés</h1>
          <div class="clearfix"></div>
          <hr>
          <form role="form" method="post" action="login.php">
            <div class="form-group">
              <label>Email*</label> <input type="email" class="form-control" name="email" placeholder=" Email " value="tesztelek@gmail.com">
            </div>
            <div class="form-group">
              <label>Jelszó*</label> <input type="password" class="form-control" name="password" placeholder="Jelszó" value="123456">
            </div>
            <input name="submit" type="submit" class="color btn btn-default" value="Bejelentkezés" />
          </form>
        </div>
      </div>
    </div>
</div>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="<?php echo APPURL; ?>/js/bootstrap.js"></script>

<?php ob_end_flush(); // End output buffering and flush output ?>
