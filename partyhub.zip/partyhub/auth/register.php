<?php require "../includes/header.php"; ?>
<?php require "../config/config.php"; ?>
<?php
if (isset($_SESSION['username'])) {
	header("location: " . APPURL . " ");
}

if (isset($_POST['submit'])) {
	if (empty($_POST['name']) or empty($_POST['email']) or empty($_POST['username']) or empty($_POST['password']) or empty($_POST['about'])) {
		echo "<script> alert('one or more inputs are empty');</script>";
	} else {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$username = $_POST['username'];
		$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
		$about = $_POST['about'];
		$avatar = $_FILES['avatar']['name'];
		$dir = "img/" . basename($avatar);

		$insert = $conn->prepare("INSERT INTO users (name, email, username, password, about, avatar) VALUES(:name, :email, :username, :password, :about, :avatar)");
		$insert->execute([
			":name" => $name,
			":email" => $email,
			":username" => $username,
			":password" => $password,
			":about" => $about,
			":avatar" => $avatar,
		]);
		header("location: login.php");
	}
}

?>
<style>
    @media screen and (min-width: 500px) {
  .row {
      margin-right:25%; 
      margin-left:25%;
  }
  .col-md-8{
      width:100%;
  }
  
}
</style>
<div  class="container">
	<div class="row" >
		<div class="col-md-8" >
			<div class="main-col">
				<div class="block">
					<h1 class="pull-left">Regisztáció</h1>

					<div class="clearfix"></div>
					<hr>
					<form role="form" enctype="multipart/form-data" method="post" action="register.php">
						<div class="form-group">
							<label>Név*</label> <input type="text" class="form-control" name="name" placeholder="Adja meg a nevét">
						</div>
						<div class="form-group">
							<label>Email*</label> <input type="email" class="form-control" name="email" placeholder="Írd be az email címed">
						</div>
						<div class="form-group">
							<label>Felhasználónév*</label> <input type="text" class="form-control" name="username" placeholder="Hozzon létre egy felhasználónevet">
						</div>
						<div class="form-group">
							<label>Jelszó*</label> <input type="password" class="form-control" name="password" placeholder="Írd be a jelszót">
						</div>
						<!-- <div class="form-group">
							<label>Confirm Password*</label> <input type="password" class="form-control" name="password2" placeholder="Enter Password Again">
						</div> -->
						<div class="form-group">
							<label>Kép feltöltés</label>
							<input type="file" name="avatar">
							<p class="help-block"></p>
						</div>
						<div class="form-group">
							<label>Mesélj magadról</label>
							<textarea id="about" rows="6" cols="80" class="form-control" name="about" placeholder="Mesélj magadról (nem kötelező)"></textarea>
						</div>
						<input name="submit" type="submit" class="color btn btn-default" value="Regisztráció" />
					</form>
				</div>
			</div>
		</div>
		
<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="<?php echo APPURL; ?>/js/bootstrap.js"></script>
